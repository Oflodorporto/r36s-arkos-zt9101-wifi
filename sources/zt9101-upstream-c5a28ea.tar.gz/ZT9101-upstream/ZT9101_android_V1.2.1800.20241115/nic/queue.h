/*
 * queue.h
 *
 * used for .....
 *
 * Author: luozhi
 *
 * Copyright (c) 2021 Shandong ZTop Microelectronics Co., Ltd
 *
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 *
 */
#ifndef __QUEUE_H__
#define __QUEUE_H__
#if 1

/* singly queue structures - entry part */
typedef struct _que_entry_t
{
    struct _que_entry_t *pnext;
    struct _que_entry_t *pprev; /* for rx buffer reordering used only */
} que_entry_t, *p_que_entry_t;

/* singly queue structures - queue part */
typedef struct _que_t
{
    p_que_entry_t phead;
    p_que_entry_t ptail;
    zt_u32 num_elem;
} que_t, *p_que_t;


#define queue_initialize(pqueue) \
    { \
        (pqueue)->phead = (p_que_entry_t)NULL; \
        (pqueue)->ptail = (p_que_entry_t)NULL; \
        (pqueue)->num_elem = 0; \
    }

#define queue_is_empty(pqueue)             (((p_que_t)(pqueue))->phead == (p_que_entry_t)NULL)

#define queue_is_not_empty(pqueue)         ((pqueue)->num_elem > 0)

#define queue_get_head(pqueue)             ((pqueue)->phead)

#define queue_get_tail(pqueue)             ((pqueue)->ptail)

#define queue_get_next_entry(pque_entry)  ((pque_entry)->pnext)

#define queue_insert_head(pqueue, pque_entry) \
    { \
        ZT_ASSERT(pqueue); \
        ZT_ASSERT(pque_entry); \
        (pque_entry)->pnext = (pqueue)->phead; \
        (pqueue)->phead = (pque_entry); \
        if ((pqueue)->ptail == (p_que_entry_t)NULL) { \
            (pqueue)->ptail = (pque_entry); \
        } \
        ((pqueue)->num_elem)++; \
    }

#define queue_insert_tail(pqueue, pque_entry) \
    { \
        ZT_ASSERT(pqueue); \
        ZT_ASSERT(pque_entry); \
        (pque_entry)->pnext = (p_que_entry_t)NULL; \
        if ((pqueue)->ptail) { \
            ((pqueue)->ptail)->pnext = (pque_entry); \
        } else { \
            (pqueue)->phead = (pque_entry); \
        } \
        (pqueue)->ptail = (pque_entry); \
        ((pqueue)->num_elem)++; \
    }

#define queue_remove_head(pqueue, pque_entry, _p_type) \
    { \
        ZT_ASSERT(pqueue); \
        pque_entry = (_p_type)((pqueue)->phead); \
        if (pque_entry) { \
            (pqueue)->phead = ((p_que_entry_t)(pque_entry))->pnext; \
            if ((pqueue)->phead == (p_que_entry_t)NULL) { \
                (pqueue)->ptail = (p_que_entry_t)NULL; \
            } \
            ((p_que_entry_t)(pque_entry))->pnext = (p_que_entry_t)NULL; \
            ((pqueue)->num_elem)--; \
        } \
    }

#define queue_move_all(pdest_que, psrc_que) \
    { \
        ZT_ASSERT(pdest_que); \
        ZT_ASSERT(psrc_que); \
        *(p_que_t)pdest_que = *(p_que_t)psrc_que; \
        queue_initialize(psrc_que); \
    }

#define queue_concatenate_queues(pdest_que, psrc_que) \
    { \
        ZT_ASSERT(pdest_que); \
        ZT_ASSERT(psrc_que); \
        if (psrc_que->num_elem > 0) { \
            if ((pdest_que)->ptail) { \
                ((pdest_que)->ptail)->pnext = (psrc_que)->phead; \
            } else { \
                (pdest_que)->phead = (psrc_que)->phead; \
            } \
            (pdest_que)->ptail = (psrc_que)->ptail; \
            ((pdest_que)->num_elem) += ((psrc_que)->num_elem); \
            queue_initialize(psrc_que); \
        } \
    }

#define queue_concatenate_queues_head(pdest_que, psrc_que) \
    { \
        ZT_ASSERT(pdest_que); \
        ZT_ASSERT(psrc_que); \
        if (psrc_que->num_elem > 0) { \
            ((psrc_que)->ptail)->pnext = (pdest_que)->phead; \
            (pdest_que)->phead = (psrc_que)->phead; \
            ((pdest_que)->num_elem) += ((psrc_que)->num_elem); \
            if ((pdest_que)->ptail == NULL) {                 \
                (pdest_que)->ptail = (psrc_que)->ptail;      \
            }  \
            queue_initialize(psrc_que); \
        } \
    }

#endif
#endif /* _queue_h */
